package com.fooddelivery.repository;

import com.fooddelivery.model.Order;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface OrderRepository extends JpaRepository<Order, Long> {
    List<Order> findByUserId(Long userId);
    List<Order> findByRestaurantId(Long restaurantId);
    List<Order> findByStatus(Order.OrderStatus status);
    
    @Query("SELECT o FROM Order o WHERE o.trackingId = :trackingId")
    Optional<Order> findByTrackingId(@Param("trackingId") String trackingId);
    
    @Query("SELECT o FROM Order o WHERE o.restaurant.id = :restaurantId AND o.orderDate >= CURRENT_DATE")
    List<Order> findTodayOrdersByRestaurantId(@Param("restaurantId") Long restaurantId);
}