package com.fooddelivery.repository;

import com.fooddelivery.model.Review;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ReviewRepository extends JpaRepository<Review, Long> {
    List<Review> findByRestaurantId(Long restaurantId);
    List<Review> findByRestaurantIdAndIsActiveTrue(Long restaurantId);
    List<Review> findByUserId(Long userId);
    
    @Query("SELECT r FROM Review r WHERE r.user.id = :userId AND r.restaurant.id = :restaurantId AND r.order.id = :orderId")
    Optional<Review> findByUserIdAndRestaurantIdAndOrderId(
        @Param("userId") Long userId, 
        @Param("restaurantId") Long restaurantId, 
        @Param("orderId") Long orderId
    );
    
    @Query("SELECT AVG(r.rating) FROM Review r WHERE r.restaurant.id = :restaurantId AND r.isActive = true")
    Double getAverageRatingByRestaurantId(@Param("restaurantId") Long restaurantId);
}