package com.fooddelivery.service;

import com.fooddelivery.model.MenuItem;
import com.fooddelivery.repository.MenuRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MenuService {
    @Autowired
    private MenuRepository menuRepository;
    
    public List<MenuItem> getAllMenuItems() {
        return menuRepository.findAll();
    }
    
    public List<MenuItem> getMenuItemsByCategory(String category) {
        return menuRepository.findByCategory(category);
    }
    
    public List<MenuItem> getMenuItemsByRestaurant(Long restaurantId) {
        return menuRepository.findByRestaurantId(restaurantId);
    }
    
    public List<MenuItem> searchMenuItems(String query) {
        return menuRepository.searchMenuItems(query);
    }
    
    public MenuItem getMenuItemById(Long id) {
        return menuRepository.findById(id).orElse(null);
    }
    
    public MenuItem saveMenuItem(MenuItem menuItem) {
        return menuRepository.save(menuItem);
    }
    
    public void deleteMenuItem(Long id) {
        menuRepository.deleteById(id);
    }
}