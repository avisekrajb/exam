package com.fooddelivery.service;

import com.fooddelivery.model.Payment;
import com.fooddelivery.repository.PaymentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PaymentService {
    @Autowired
    private PaymentRepository paymentRepository;
    
    public Payment savePayment(Payment payment) {
        return paymentRepository.save(payment);
    }
    
    public Optional<Payment> getPaymentById(Long id) {
        return paymentRepository.findById(id);
    }
    
    public Optional<Payment> getPaymentByOrderId(Long orderId) {
        // Implementation would query by order ID
        return Optional.empty();
    }
}