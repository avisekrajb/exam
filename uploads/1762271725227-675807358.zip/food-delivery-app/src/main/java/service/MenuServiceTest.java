package com.fooddelivery.service;

import com.fooddelivery.model.MenuItem;
import com.fooddelivery.repository.MenuRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@SpringBootTest
class MenuServiceTest {
    @Autowired
    private MenuService menuService;
    
    @MockBean
    private MenuRepository menuRepository;
    
    @Test
    void shouldReturnAllMenuItems() {
        MenuItem item1 = new MenuItem("Pizza", "Delicious pizza", 12.99, "/images/pizza.jpg", "Pizza");
        MenuItem item2 = new MenuItem("Burger", "Tasty burger", 9.99, "/images/burger.jpg", "Burgers");
        
        when(menuRepository.findAll()).thenReturn(Arrays.asList(item1, item2));
        
        List<MenuItem> items = menuService.getAllMenuItems();
        assertEquals(2, items.size());
    }
}