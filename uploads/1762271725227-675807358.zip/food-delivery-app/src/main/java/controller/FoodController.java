package com.fooddelivery.controller;

import com.fooddelivery.model.*;
import com.fooddelivery.payload.request.OrderRequest;
import com.fooddelivery.payload.request.ReviewRequest;
import com.fooddelivery.payload.response.OrderResponse;
import com.fooddelivery.repository.OrderRepository;
import com.fooddelivery.repository.RestaurantRepository;
import com.fooddelivery.repository.ReviewRepository;
import com.fooddelivery.service.UserDetailsImpl;
import com.fooddelivery.service.MenuService;
import com.fooddelivery.service.OrderService;
import com.fooddelivery.service.PaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class FoodController {
    @Autowired
    private MenuService menuService;
    
    @Autowired
    private OrderService orderService;
    
    @Autowired
    private PaymentService paymentService;
    
    @Autowired
    private RestaurantRepository restaurantRepository;
    
    @Autowired
    private OrderRepository orderRepository;
    
    @Autowired
    private ReviewRepository reviewRepository;
    
    // Menu endpoints
    @GetMapping("/menu")
    public List<MenuItem> getMenu() {
        return menuService.getAllMenuItems();
    }
    
    @GetMapping("/menu/{restaurantId}")
    public List<MenuItem> getMenuByRestaurant(@PathVariable Long restaurantId) {
        return menuService.getMenuItemsByRestaurant(restaurantId);
    }
    
    @GetMapping("/menu/search")
    public List<MenuItem> searchMenu(@RequestParam String query) {
        return menuService.searchMenuItems(query);
    }
    
    @PostMapping("/menu")
    @PreAuthorize("hasRole('RESTAURANT_MANAGER') or hasRole('ADMIN')")
    public MenuItem addMenuItem(@RequestBody MenuItem menuItem) {
        return menuService.saveMenuItem(menuItem);
    }
    
    // Restaurant endpoints
    @GetMapping("/restaurants")
    public List<Restaurant> getRestaurants() {
        return restaurantRepository.findByIsActiveTrue();
    }
    
    @GetMapping("/restaurants/{id}")
    public ResponseEntity<Restaurant> getRestaurant(@PathVariable Long id) {
        Optional<Restaurant> restaurant = restaurantRepository.findById(id);
        return restaurant.map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }
    
    @GetMapping("/restaurants/search")
    public List<Restaurant> searchRestaurants(@RequestParam String query) {
        return restaurantRepository.searchRestaurants(query);
    }
    
    // Order endpoints
    @GetMapping("/orders")
    @PreAuthorize("hasRole('USER')")
    public List<OrderResponse> getUserOrders(@AuthenticationPrincipal UserDetailsImpl userDetails) {
        return orderService.getUserOrders(userDetails.getId()).stream()
                .map(this::convertToOrderResponse)
                .collect(Collectors.toList());
    }
    
    @GetMapping("/orders/{id}")
    public ResponseEntity<OrderResponse> getOrder(@PathVariable Long id, @AuthenticationPrincipal UserDetailsImpl userDetails) {
        Optional<Order> order = orderService.getOrderById(id);
        
        if (order.isPresent()) {
            // Check if user has access to this order
            if (!order.get().getUser().getId().equals(userDetails.getId()) && 
                !userDetails.getAuthorities().stream().anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN") || a.getAuthority().equals("ROLE_RESTAURANT_MANAGER"))) {
                return ResponseEntity.status(403).build();
            }
            
            return ResponseEntity.ok(convertToOrderResponse(order.get()));
        }
        
        return ResponseEntity.notFound().build();
    }
    
    @PostMapping("/orders")
    @PreAuthorize("hasRole('USER')")
    public ResponseEntity<OrderResponse> placeOrder(@Valid @RequestBody OrderRequest orderRequest, 
                                                   @AuthenticationPrincipal UserDetailsImpl userDetails) {
        try {
            // Implementation would convert OrderRequest to Order and save it
            Order order = new Order();
            order.setUser(new User(userDetails.getId()));
            order.setRestaurant(new Restaurant(orderRequest.getRestaurantId()));
            order.setCustomerName(orderRequest.getCustomerName());
            order.setCustomerAddress(orderRequest.getCustomerAddress());
            order.setCustomerPhone(orderRequest.getCustomerPhone());
            order.setCustomerEmail(orderRequest.getCustomerEmail());
            order.setOrderDate(new java.util.Date());
            order.setStatus(Order.OrderStatus.PENDING);
            
            // Generate tracking ID
            String trackingId = "TRK" + UUID.randomUUID().toString().replace("-", "").substring(0, 10).toUpperCase();
            order.setTrackingId(trackingId);
            
            Order savedOrder = orderService.saveOrder(order);
            
            return ResponseEntity.ok(convertToOrderResponse(savedOrder));
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }
    
    @PutMapping("/orders/{id}/status")
    @PreAuthorize("hasRole('RESTAURANT_MANAGER') or hasRole('ADMIN')")
    public ResponseEntity<Order> updateOrderStatus(@PathVariable Long id, @RequestParam Order.OrderStatus status) {
        Optional<Order> order = orderService.getOrderById(id);
        
        if (order.isPresent()) {
            Order updatedOrder = order.get();
            updatedOrder.setStatus(status);
            
            // Update timestamps based on status
            switch (status) {
                case ACCEPTED:
                    updatedOrder.setAcceptedDate(new java.util.Date());
                    break;
                case PREPARING:
                    updatedOrder.setPreparingDate(new java.util.Date());
                    break;
                case OUT_FOR_DELIVERY:
                    updatedOrder.setOutForDeliveryDate(new java.util.Date());
                    break;
                case DELIVERED:
                    updatedOrder.setDeliveredDate(new java.util.Date());
                    break;
            }
            
            orderRepository.save(updatedOrder);
            
            // Send real-time notification (would integrate with WebSocket or push service)
            sendOrderStatusNotification(updatedOrder);
            
            return ResponseEntity.ok(updatedOrder);
        }
        
        return ResponseEntity.notFound().build();
    }
    
    // Review endpoints
    @PostMapping("/reviews")
    @PreAuthorize("hasRole('USER')")
    public ResponseEntity<Review> addReview(@Valid @RequestBody ReviewRequest reviewRequest, 
                                           @AuthenticationPrincipal UserDetailsImpl userDetails) {
        // Check if user has already reviewed this restaurant for this order
        Optional<Review> existingReview = reviewRepository.findByUserIdAndRestaurantIdAndOrderId(
            userDetails.getId(), reviewRequest.getRestaurantId(), reviewRequest.getOrderId());
        
        if (existingReview.isPresent()) {
            return ResponseEntity.badRequest().build();
        }
        
        // Check if order exists and was delivered
        Optional<Order> order = orderRepository.findById(reviewRequest.getOrderId());
        if (!order.isPresent() || !order.get().getStatus().equals(Order.OrderStatus.DELIVERED) || 
            !order.get().getUser().getId().equals(userDetails.getId())) {
            return ResponseEntity.badRequest().build();
        }
        
        Review review = new Review();
        review.setUser(new User(userDetails.getId()));
        review.setRestaurant(new Restaurant(reviewRequest.getRestaurantId()));
        review.setOrder(order.get());
        review.setRating(reviewRequest.getRating());
        review.setComment(reviewRequest.getComment());
        review.setReviewDate(new java.util.Date());
        
        Review savedReview = reviewRepository.save(review);
        
        // Update restaurant rating
        updateRestaurantRating(reviewRequest.getRestaurantId());
        
        return ResponseEntity.ok(savedReview);
    }
    
    @GetMapping("/restaurants/{restaurantId}/reviews")
    public List<Review> getRestaurantReviews(@PathVariable Long restaurantId) {
        return reviewRepository.findByRestaurantIdAndIsActiveTrue(restaurantId);
    }
    
    // Payment endpoints
    @PostMapping("/payments")
    @PreAuthorize("hasRole('USER')")
    public ResponseEntity<Payment> processPayment(@RequestBody Payment payment, 
                                                 @AuthenticationPrincipal UserDetailsImpl userDetails) {
        // Validate payment details (in a real app, integrate with payment gateway)
        payment.setPaymentStatus("COMPLETED");
        payment.setPaymentDate(new java.util.Date());
        
        Payment savedPayment = paymentService.savePayment(payment);
        
        // Update order status
        Optional<Order> order = orderRepository.findById(payment.getOrder().getId());
        if (order.isPresent()) {
            Order updatedOrder = order.get();
            updatedOrder.setStatus(Order.OrderStatus.ACCEPTED);
            updatedOrder.setAcceptedDate(new java.util.Date());
            orderRepository.save(updatedOrder);
        }
        
        return ResponseEntity.ok(savedPayment);
    }
    
    // Admin endpoints
    @GetMapping("/admin/orders")
    @PreAuthorize("hasRole('ADMIN')")
    public List<Order> getAllOrders() {
        return orderService.getAllOrders();
    }
    
    // Helper methods
    private OrderResponse convertToOrderResponse(Order order) {
        OrderResponse response = new OrderResponse();
        response.setId(order.getId());
        response.setStatus(order.getStatus());
        response.setTotalAmount(order.getTotalAmount());
        response.setOrderDate(order.getOrderDate());
        response.setTrackingId(order.getTrackingId());
        response.setRestaurantName(order.getRestaurant().getName());
        // response.setEstimatedDeliveryTime(calculateEstimatedDeliveryTime(order));
        return response;
    }
    
    private void updateRestaurantRating(Long restaurantId) {
        List<Review> reviews = reviewRepository.findByRestaurantIdAndIsActiveTrue(restaurantId);
        double averageRating = reviews.stream()
                .mapToInt(Review::getRating)
                .average()
                .orElse(0.0);
        
        int ratingCount = reviews.size();
        
        Optional<Restaurant> restaurant = restaurantRepository.findById(restaurantId);
        if (restaurant.isPresent()) {
            Restaurant rest = restaurant.get();
            rest.setRating(averageRating);
            rest.setRatingCount(ratingCount);
            restaurantRepository.save(rest);
        }
    }
    
    private void sendOrderStatusNotification(Order order) {
        // Implementation would integrate with WebSocket, Firebase Cloud Messaging, or similar
        System.out.println("Notification: Order " + order.getTrackingId() + " status changed to " + order.getStatus());
    }
}