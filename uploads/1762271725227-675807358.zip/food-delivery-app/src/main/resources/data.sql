-- Insert roles
INSERT INTO roles (name) VALUES ('ROLE_USER');
INSERT INTO roles (name) VALUES ('ROLE_RESTAURANT_MANAGER');
INSERT INTO roles (name) VALUES ('ROLE_ADMIN');

-- Insert sample restaurants
INSERT INTO restaurants (name, description, address, phone, email, image, rating, rating_count, is_active) VALUES 
('Pizza Palace', 'Best pizza in town', '123 Main St', '555-1234', 'info@pizzapalace.com', '/images/restaurant1.jpg', 4.5, 120, true),
('Burger Barn', 'Juicy burgers and fries', '456 Oak Ave', '555-5678', 'contact@burgerbarn.com', '/images/restaurant2.jpg', 4.2, 85, true),
('Sushi Spot', 'Fresh Japanese cuisine', '789 Pine Rd', '555-9012', 'hello@sushispot.com', '/images/restaurant3.jpg', 4.7, 200, true);

-- Insert sample menu items
INSERT INTO menu_items (name, description, price, image, category, restaurant_id) VALUES 
('Margherita Pizza', 'Classic pizza with tomato sauce and mozzarella', 12.99, '/images/pizza-margherita.jpg', 'Pizza', 1),
('Pepperoni Pizza', 'Pizza with tomato sauce, mozzarella, and pepperoni', 14.99, '/images/pizza-pepperoni.jpg', 'Pizza', 1),
('Veggie Supreme Pizza', 'Pizza with assorted vegetables', 13.99, '/images/pizza-veggie.jpg', 'Pizza', 1),
('Chicken Burger', 'Juicy chicken burger with lettuce and mayo', 9.99, '/images/burger-chicken.jpg', 'Burgers', 2),
('Beef Burger', 'Classic beef burger with cheese and pickles', 10.99, '/images/burger-beef.jpg', 'Burgers', 2),
('Veggie Burger', 'Plant-based burger with fresh vegetables', 8.99, '/images/burger-veggie.jpg', 'Burgers', 2),
('California Roll', 'Avocado, crab, and cucumber', 8.99, '/images/sushi-california.jpg', 'Sushi', 3),
('Salmon Nigiri', 'Fresh salmon over rice', 6.99, '/images/sushi-salmon.jpg', 'Sushi', 3),
('Dragon Roll', 'Eel, avocado, and cucumber', 12.99, '/images/sushi-dragon.jpg', 'Sushi', 3);