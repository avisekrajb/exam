// Main application logic
let currentPage = 'home';

// Initialize the application
function initApp() {
    loadContent();
    setupNavigation();
    loadNotifications();
}

// Load content based on current page
function loadContent() {
    const mainContent = document.getElementById('mainContent');
    
    switch (currentPage) {
        case 'home':
            showHome();
            break;
        case 'menu':
            showMenu();
            break;
        case 'restaurants':
            showRestaurants();
            break;
        case 'profile':
            showProfile();
            break;
        case 'orders':
            showOrderHistory();
            break;
        case 'tracking':
            showOrderTracking();
            break;
        default:
            showHome();
    }
}

// Setup navigation
function setupNavigation() {
    // Add click event listeners to navigation links
    const navLinks = document.querySelectorAll('.nav-links a');
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const target = this.getAttribute('href').substring(1);
            navigateTo(target);
        });
    });
}

// Navigate to a specific page
function navigateTo(page) {
    currentPage = page;
    loadContent();
    
    // Update active link
    const navLinks = document.querySelectorAll('.nav-links a');
    navLinks.forEach(link => {
        if (link.getAttribute('href') === `#${page}`) {
            link.classList.add('active');
        } else {
            link.classList.remove('active');
        }
    });
}

// Show home page
function showHome() {
    const mainContent = document.getElementById('mainContent');
    mainContent.innerHTML = `
        <section class="hero" id="home">
            <h1>Delicious food delivered to your door</h1>
            <p>Order from your favorite restaurants with just a few clicks and enjoy a freshly prepared meal at home.</p>
            <button class="btn btn-primary" onclick="navigateTo('restaurants')">Order Now</button>
        </section>
        
        <section class="container">
            <h2 class="section-title">Featured Restaurants</h2>
            <div class="restaurant-grid" id="featuredRestaurants">
                <!-- Featured restaurants will be loaded here -->
            </div>
        </section>
        
        <section class="container">
            <h2 class="section-title">Popular Dishes</h2>
            <div class="menu-grid" id="popularDishes">
                <!-- Popular dishes will be loaded here -->
            </div>
        </section>
    `;
    
    // Load featured restaurants and popular dishes
    loadFeaturedRestaurants();
    loadPopularDishes();
}

// Show menu page
function showMenu() {
    const mainContent = document.getElementById('mainContent');
    mainContent.innerHTML = `
        <section class="container">
            <h2 class="section-title">Our Menu</h2>
            <div class="category-filter">
                <button class="filter-btn active" data-category="all">All</button>
                <button class="filter-btn" data-category="Pizza">Pizza</button>
                <button class="filter-btn" data-category="Burgers">Burgers</button>
                <button class="filter-btn" data-category="Salads">Salads</button>
                <button class="filter-btn" data-category="Sides">Sides</button>
                <button class="filter-btn" data-category="Drinks">Drinks</button>
                <button class="filter-btn" data-category="Desserts">Desserts</button>
            </div>
            <div class="menu-grid" id="menuGrid">
                <!-- Menu items will be loaded here -->
            </div>
        </section>
    `;
    
    // Load menu items
    loadMenuItems();
    setupCategoryFilters();
}

// Show restaurants page
function showRestaurants() {
    const mainContent = document.getElementById('mainContent');
    mainContent.innerHTML = `
        <section class="container">
            <h2 class="section-title">Our Restaurants</h2>
            <div class="search-bar">
                <input type="text" id="restaurantSearch" placeholder="Search restaurants...">
                <button class="btn btn-primary" onclick="searchRestaurants()">Search</button>
            </div>
            <div class="restaurant-grid" id="restaurantGrid">
                <!-- Restaurants will be loaded here -->
            </div>
        </section>
    `;
    
    // Load restaurants
    loadRestaurants();
}

// Show user profile
function showProfile() {
    if (!currentUser) {
        showNotification('Please login to view your profile.', 'error');
        showLogin();
        return;
    }
    
    const mainContent = document.getElementById('mainContent');
    mainContent.innerHTML = `
        <section class="container">
            <div class="user-profile">
                <h2>My Profile</h2>
                <div class="profile-info">
                    <p><strong>Username:</strong> <span id="profileUsername">${currentUser.username}</span></p>
                    <p><strong>Email:</strong> <span id="profileEmail">${currentUser.email}</span></p>
                    <p><strong>Phone:</strong> <span id="profilePhone">Not set</span></p>
                    <p><strong>Address:</strong> <span id="profileAddress">Not set</span></p>
                </div>
                <button class="btn btn-secondary" onclick="editProfile()">Edit Profile</button>
                <button class="btn btn-primary" onclick="showOrderHistory()">Order History</button>
                <button class="btn btn-warning" onclick="showOrderTracking()">Track Order</button>
            </div>
        </section>
    `;
    
    // Load user details
    loadUserDetails();
}

// Show order history
function showOrderHistory() {
    if (!currentUser) {
        showNotification('Please login to view your order history.', 'error');
        showLogin();
        return;
    }
    
    const mainContent = document.getElementById('mainContent');
    mainContent.innerHTML = `
        <section class="container">
            <h2 class="section-title">Order History</h2>
            <div class="orders-history" id="ordersHistory">
                <!-- Orders will be loaded here -->
            </div>
        </section>
    `;
    
    // Load user orders
    loadUserOrders();
}

// Show order tracking
function showOrderTracking() {
    const mainContent = document.getElementById('mainContent');
    mainContent.innerHTML = `
        <section class="container">
            <div class="order-tracking">
                <h2>Track Your Order</h2>
                <div class="tracking-input">
                    <input type="text" id="trackingId" placeholder="Enter Tracking ID">
                    <button class="btn btn-primary" onclick="trackOrder()">Track</button>
                </div>
                <div class="tracking-progress" id="trackingProgress">
                    <!-- Tracking progress will be shown here -->
                </div>
                <div class="order-details" id="orderDetails">
                    <!-- Order details will be shown here -->
                </div>
            </div>
        </section>
    `;
}

// Initialize the app when DOM is loaded
window.addEventListener('DOMContentLoaded', initApp);